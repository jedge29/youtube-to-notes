import openai

openai.api_key = "your-openai-key-here"

def summarize_transcript(text):
    prompt = f"""
You are a helpful assistant. Summarize this YouTube transcript into bullet points with important ideas.

Transcript:
{text[:4000]}
"""

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content
