import yt_dlp
import requests

def get_subtitle_url(video_url):
    ydl_opts = {
        'skip_download': True,
        'quiet': True,
        'writesubtitles': True,
        'writeautomaticsub': True,
        'subtitleslangs': ['en'],
        'outtmpl': '%(id)s',
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(video_url, download=False)
        subtitles = info.get('automatic_captions', {})
        if 'en' in subtitles:
            return subtitles['en'][0]['url']
        return None

def fetch_transcript_text(subtitle_url):
    response = requests.get(subtitle_url)
    lines = response.text.splitlines()
    transcript = []

    for line in lines:
        if "-->" in line or line.strip() == "":
            continue
        transcript.append(line.strip())

    return " ".join(transcript)
