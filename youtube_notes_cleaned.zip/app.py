import streamlit as st
from transcript import get_subtitle_url, fetch_transcript_text
from summarize import summarize_transcript
from utils import export_to_pdf, convert_to_markdown

st.set_page_config(page_title="YouTube to Notes", layout="centered")
st.title("YouTube to Notes")
st.subheader("Summarize any YouTube video into bullet-point notes.")

video_url = st.text_input("Paste YouTube link here")

if st.button("Generate Notes") and video_url:
    with st.spinner("Fetching transcript..."):
        subtitle_url = get_subtitle_url(video_url)

    if subtitle_url:
        with st.spinner("Parsing and summarizing..."):
            transcript_text = fetch_transcript_text(subtitle_url)
            summary = summarize_transcript(transcript_text)

            st.subheader("Summary:")
            st.write(summary)

            markdown_summary = convert_to_markdown(summary)
            st.subheader("Copy to Notion/Markdown:")
            st.text_area("", markdown_summary, height=300)

            # PDF Download
            pdf_path = export_to_pdf(summary)
            with open(pdf_path, "rb") as file:
                st.download_button("Download PDF", file, "notes.pdf", "application/pdf")
    else:
        st.error("No English subtitles found for this video.")
